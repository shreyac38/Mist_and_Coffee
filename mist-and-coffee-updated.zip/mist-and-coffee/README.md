# Mist and Coffee — React + Supabase cafe ordering website

## Run locally

```bash
npm install
npm run dev
```

Open the Vite URL (usually http://localhost:5173).

## Supabase setup

1. Create a Supabase project and run `supabase/schema.sql` in SQL Editor.
2. Create a staff user in Authentication → Users.
3. Grant admin role with `update public.profiles set role='admin' where id='YOUR-USER-UUID';`.
4. Copy `.env.example` to `.env`, add Project URL and anon/public key, then restart Vite.
5. Open `/admin` to sign in.

See `supabase/README-ADMIN.md` for the admin setup steps.

## Included
- Premium responsive cafe storefront, INR prices and 9 AM–9 PM hours.
- Sample menu that loads dynamically from Supabase when configured.
- Search, category filters, cart and checkout.
- Pickup / delivery and cash / pay-at-cafe checkout.
- Atomic order creation RPC that recalculates totals from database menu prices.
- `/admin` staff login, menu CRUD and order status dashboard.
- RLS policies for public menu reading and admin-only management.

Cafe address and contact number were not provided, so the address is marked as coming soon and no phone is displayed. Replace sample menu entries, images, address and contact details before public launch. Add delivery-zone and fee rules, abuse protection, privacy notice and production monitoring before accepting real public orders.
