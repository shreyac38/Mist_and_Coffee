# Supabase setup — Mist and Coffee

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Create your staff/admin login in Authentication → Users.
4. Copy that user's UUID and run this in SQL Editor (replace the placeholder):

```sql
update public.profiles set role = 'admin' where id = 'PASTE-AUTH-USER-UUID-HERE';
```

5. Copy `.env.example` to `.env`, enter the Project URL and anon/public key, and restart Vite.
6. Open `/admin` and sign in.

Never put a service-role key in frontend code. The checkout RPC calculates prices from menu records in the database and writes order + order items atomically. Test policies and RPC in a non-production project before launch.
