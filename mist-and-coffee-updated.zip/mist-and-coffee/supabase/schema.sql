-- Mist and Coffee: execute in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade, role text not null default 'customer' check (role in ('customer','admin')), created_at timestamptz not null default now());
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,role) values(new.id,'customer') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile after insert on auth.users for each row execute procedure public.handle_new_user();
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
create table if not exists public.categories (id uuid primary key default gen_random_uuid(),name text not null unique,sort_order integer not null default 0,created_at timestamptz not null default now());
create table if not exists public.food_items (id uuid primary key default gen_random_uuid(),name text not null,description text not null default '',category_id uuid references public.categories(id) on delete set null,price numeric(10,2) not null check(price>=0),image_url text,is_available boolean not null default true,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create table if not exists public.orders (id uuid primary key default gen_random_uuid(),order_code text not null unique,customer_name text not null,phone text not null,email text,fulfilment text not null check(fulfilment in('Pickup','Delivery')),delivery_address text,payment_method text not null check(payment_method in('Pay at cafe','Cash on delivery')),notes text,total_amount numeric(10,2) not null check(total_amount>=0),status text not null default 'received' check(status in('received','confirmed','preparing','ready','out_for_delivery','completed','cancelled')),created_at timestamptz not null default now(),constraint delivery_address_required check(fulfilment<>'Delivery' or nullif(trim(delivery_address),'') is not null));
create table if not exists public.order_items (id uuid primary key default gen_random_uuid(),order_id uuid not null references public.orders(id) on delete cascade,food_item_id uuid references public.food_items(id) on delete set null,item_name text not null,unit_price numeric(10,2) not null check(unit_price>=0),quantity integer not null check(quantity>0));
insert into public.categories(name,sort_order) values('Coffee',1),('Cold brews',2),('Bakery',3),('Desserts',4),('Small plates',5) on conflict(name) do nothing;
do $$ begin if not exists(select 1 from public.food_items) then insert into public.food_items(name,description,category_id,price,image_url) select v.name,v.description,c.id,v.price,v.image_url from (values
('Cloud Nine Latte','Double espresso, silky milk and a whisper of vanilla.','Coffee',180,'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85'),('Velvet Cappuccino','A rich espresso with soft, cloud-like milk foam.','Coffee',160,'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=900&q=85'),('Iced Spanish Latte','Chilled espresso blended with sweet, creamy milk.','Cold brews',210,'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=85'),('Mocha Mood','Espresso meets dark chocolate in a comforting cup.','Coffee',200,'https://images.unsplash.com/photo-1578374173705-2c1d8a3c2d9e?auto=format&fit=crop&w=900&q=85'),('Butter Croissant','Flaky, golden layers baked fresh every morning.','Bakery',130,'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=900&q=85'),('Blueberry Cheesecake','Creamy baked cheesecake with a bright berry finish.','Desserts',220,'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=85'),('Truffle Mushroom Toast','Sourdough, buttery mushrooms and a hint of herbs.','Small plates',260,'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=85'),('Matcha Cloud','Matcha shaken with chilled oat milk.','Cold brews',230,'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=900&q=85')) as v(name,description,category,price,image_url) join public.categories c on c.name=v.category; end if; end $$;
alter table public.profiles enable row level security; alter table public.categories enable row level security; alter table public.food_items enable row level security; alter table public.orders enable row level security; alter table public.order_items enable row level security;
drop policy if exists "Profile owner or admin can read profiles" on public.profiles; create policy "Profile owner or admin can read profiles" on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
drop policy if exists "Public can read categories" on public.categories; create policy "Public can read categories" on public.categories for select to anon,authenticated using(true);
drop policy if exists "Admins manage categories" on public.categories; create policy "Admins manage categories" on public.categories for all to authenticated using(public.is_admin()) with check(public.is_admin());
drop policy if exists "Public can read available food" on public.food_items; create policy "Public can read available food" on public.food_items for select to anon,authenticated using(is_available=true or public.is_admin());
drop policy if exists "Admins manage food" on public.food_items; create policy "Admins manage food" on public.food_items for all to authenticated using(public.is_admin()) with check(public.is_admin());
drop policy if exists "Customers can submit orders" on public.orders; drop policy if exists "Admins read and update orders" on public.orders; create policy "Admins read and update orders" on public.orders for all to authenticated using(public.is_admin()) with check(public.is_admin());
drop policy if exists "Admins read order items" on public.order_items; create policy "Admins read order items" on public.order_items for select to authenticated using(public.is_admin());
-- Atomic public checkout: accepts item IDs and quantities, calculates trusted prices in SQL.
create or replace function public.create_customer_order(p_customer_name text,p_phone text,p_email text,p_fulfilment text,p_delivery_address text,p_payment_method text,p_notes text,p_items jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_order_id uuid; v_order_code text:='MC'||upper(substr(encode(gen_random_bytes(4),'hex'),1,6)); v_total numeric(10,2):=0; v_item jsonb; v_food public.food_items%rowtype; v_qty integer;
begin
 if nullif(trim(p_customer_name),'') is null or nullif(trim(p_phone),'') is null then raise exception 'Name and phone number are required'; end if;
 if p_fulfilment not in('Pickup','Delivery') then raise exception 'Invalid fulfilment option'; end if;
 if p_payment_method not in('Pay at cafe','Cash on delivery') then raise exception 'Invalid payment method'; end if;
 if p_fulfilment='Delivery' and nullif(trim(p_delivery_address),'') is null then raise exception 'Delivery address is required'; end if;
 if p_items is null or jsonb_typeof(p_items) is distinct from 'array' or jsonb_array_length(p_items)=0 then raise exception 'Your cart is empty'; end if;
 for v_item in select value from jsonb_array_elements(p_items) loop
  v_qty:=(v_item->>'quantity')::integer; if v_qty is null or v_qty<1 or v_qty>50 then raise exception 'Invalid item quantity'; end if;
  select * into v_food from public.food_items where id=(v_item->>'food_item_id')::uuid and is_available=true for share; if not found then raise exception 'One of the selected items is unavailable'; end if;
  v_total:=v_total+(v_food.price*v_qty);
 end loop;
 insert into public.orders(order_code,customer_name,phone,email,fulfilment,delivery_address,payment_method,notes,total_amount) values(v_order_code,trim(p_customer_name),trim(p_phone),nullif(trim(p_email),''),p_fulfilment,nullif(trim(p_delivery_address),''),p_payment_method,nullif(trim(p_notes),''),v_total) returning id into v_order_id;
 for v_item in select value from jsonb_array_elements(p_items) loop
  v_qty:=(v_item->>'quantity')::integer; select * into v_food from public.food_items where id=(v_item->>'food_item_id')::uuid and is_available=true for share;
  insert into public.order_items(order_id,food_item_id,item_name,unit_price,quantity) values(v_order_id,v_food.id,v_food.name,v_food.price,v_qty);
 end loop;
 return jsonb_build_object('id',v_order_id,'order_code',v_order_code,'total_amount',v_total);
end; $$;
revoke all on function public.create_customer_order(text,text,text,text,text,text,text,jsonb) from public; grant execute on function public.create_customer_order(text,text,text,text,text,text,text,jsonb) to anon,authenticated;

-- Enable realtime notifications for the staff order board where publication exists.
do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='orders') then
    execute 'alter publication supabase_realtime add table public.orders';
  end if;
end $$;
